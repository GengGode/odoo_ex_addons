# -*- coding: utf-8 -*-

from . import res_users
from . import res_partner
from . import wo_config
from . import wo_confirm_wizard
